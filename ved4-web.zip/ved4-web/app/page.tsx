import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Achievements from "@/components/Achievements";
import PensumExplorer from "@/components/PensumExplorer";
import CurriculumSimulator from "@/components/CurriculumSimulator";
import ScholarshipCenter from "@/components/ScholarshipCenter";
import Gallery from "@/components/Gallery";
import Community from "@/components/Community";
import Footer from "@/components/Footer";

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main id="contenido">
        <Hero />
        <About />
        <Achievements />
        <PensumExplorer />
        <CurriculumSimulator />
        <ScholarshipCenter />
        <Gallery />
        <Community />
      </main>
      <Footer />
    </>
  );
}
