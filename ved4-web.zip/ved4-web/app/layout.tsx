import type { Metadata, Viewport } from "next";
import { Inter, Sora } from "next/font/google";
import "./globals.css";

const display = Sora({ subsets: ["latin"], variable: "--font-display", display: "swap" });
const body = Inter({ subsets: ["latin"], variable: "--font-body", display: "swap" });

export const metadata: Metadata = {
  title: "VED4 Santiago | Vanguardia Estudiantil Dominicana, Recinto UASD Santiago",
  description:
    "Plataforma de la Vanguardia Estudiantil Dominicana (VED4) en la UASD Santiago: pensum por facultad, simulador curricular, becas, trámites y comunidad.",
  openGraph: {
    title: "VED4 Santiago | Vanguardia Estudiantil Dominicana",
    description: "Pensum por facultad, simulador curricular, becas y comunidad estudiantil en la UASD Santiago.",
    locale: "es_DO",
    type: "website",
  },
  icons: { icon: "/brand/ved4-logo.png" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0A1C3B",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" className={`${display.variable} ${body.variable}`}>
      <body>
        <a
          href="#contenido"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-navy-900"
        >
          Saltar al contenido
        </a>
        {children}
      </body>
    </html>
  );
}
