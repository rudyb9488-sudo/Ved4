export interface Career {
  name: string;
  /** Código institucional de la carrera (ej. 40601). */
  code: string;
  /** Código de programa usado por el portal (ej. P-INFO). */
  program: string;
  /** Código de plan de estudios (ej. 200820). */
  plan: string;
}

export interface School {
  name: string;
  careers: Career[];
}

export interface Faculty {
  id: string;
  name: string;
  /** Siglas de 2 letras para el distintivo de la facultad. */
  monogram: string;
  color: string;
  schools: School[];
}

export type PeriodType = "semestre" | "cuatrimestre";
