import type { Career } from "./types";

export const PLANES_URL = "https://app.uasd.edu.do/planesgrado/";

export function pensumUrl(career: Pick<Career, "program" | "plan">): string {
  const params = new URLSearchParams({
    periodoV: "999999",
    programa: career.program,
    plan: career.plan,
    nivel: "GR",
  });
  return `https://app.uasd.edu.do/PensumGrado/?${params.toString()}`;
}

export function normalize(text: string): string {
  return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

export function careerLevel(name: string): string {
  const n = normalize(name);
  if (n.startsWith("doctor")) return "Doctorado profesional";
  if (n.startsWith("ingenieria")) return "Ingeniería";
  if (n.startsWith("tecnologo") || n.startsWith("tecnologia")) return "Tecnólogo";
  if (n.startsWith("tecnico")) return "Técnico";
  if (n.startsWith("certificado")) return "Certificado";
  if (n.startsWith("pre-medica")) return "Preparatorio";
  return "Licenciatura";
}
