import type { PeriodType } from "./types";

export interface SimulatorInput {
  totalSubjects: number;
  approvedSubjects: number;
  perPeriod: number;
  periodType: PeriodType;
  startYear: number;
  /** Número de período dentro del año (1 = primero). */
  startPeriod: number;
}

export interface PeriodRow {
  index: number;
  label: string;
  subjects: number;
  cumulative: number;
  remaining: number;
}

export interface SimulatorResult {
  remaining: number;
  periods: number;
  periodsPerYear: number;
  years: number;
  extraPeriods: number;
  endLabel: string;
  load: "ligera" | "moderada" | "intensa";
  progressPercent: number;
  rows: PeriodRow[];
}

export const periodsPerYear: Record<PeriodType, number> = {
  semestre: 2,
  cuatrimestre: 3,
};

export const periodNoun: Record<PeriodType, string> = {
  semestre: "semestre",
  cuatrimestre: "cuatrimestre",
};

export function periodLabel(type: PeriodType, year: number, period: number): string {
  return `${type === "semestre" ? "Semestre" : "Cuatrimestre"} ${period} de ${year}`;
}

function loadLevel(perPeriod: number, type: PeriodType): SimulatorResult["load"] {
  const light = type === "semestre" ? 4 : 3;
  const moderate = type === "semestre" ? 6 : 5;
  if (perPeriod <= light) return "ligera";
  if (perPeriod <= moderate) return "moderada";
  return "intensa";
}

export function simulate(input: SimulatorInput): SimulatorResult | null {
  const { totalSubjects, approvedSubjects, perPeriod, periodType, startYear, startPeriod } = input;
  const valid =
    Number.isInteger(totalSubjects) &&
    Number.isInteger(approvedSubjects) &&
    Number.isInteger(perPeriod) &&
    totalSubjects > 0 &&
    approvedSubjects >= 0 &&
    approvedSubjects <= totalSubjects &&
    perPeriod > 0 &&
    perPeriod <= 20;
  if (!valid) return null;

  const ppy = periodsPerYear[periodType];
  const remaining = totalSubjects - approvedSubjects;
  const periods = Math.ceil(remaining / perPeriod);

  const rows: PeriodRow[] = [];
  let left = remaining;
  let done = 0;
  for (let i = 0; i < periods; i += 1) {
    const subjects = Math.min(perPeriod, left);
    left -= subjects;
    done += subjects;
    const offset = startPeriod - 1 + i;
    rows.push({
      index: i + 1,
      label: periodLabel(periodType, startYear + Math.floor(offset / ppy), (offset % ppy) + 1),
      subjects,
      cumulative: approvedSubjects + done,
      remaining: left,
    });
  }

  const endLabel = rows.length > 0 ? rows[rows.length - 1].label : "Carrera completada";

  return {
    remaining,
    periods,
    periodsPerYear: ppy,
    years: Math.floor(periods / ppy),
    extraPeriods: periods % ppy,
    endLabel,
    load: loadLevel(perPeriod, periodType),
    progressPercent: Math.round((approvedSubjects / totalSubjects) * 100),
    rows,
  };
}

export function durationText(result: SimulatorResult, type: PeriodType): string {
  if (result.periods === 0) return "Ya completaste todas las materias";
  const noun = periodNoun[type];
  const parts: string[] = [];
  if (result.years > 0) parts.push(`${result.years} ${result.years === 1 ? "año" : "años"}`);
  if (result.extraPeriods > 0) {
    parts.push(`${result.extraPeriods} ${result.extraPeriods === 1 ? noun : `${noun}s`}`);
  }
  return parts.join(" y ");
}
