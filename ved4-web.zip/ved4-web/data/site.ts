import type { Faculty } from "@/lib/types";

export const site = {
  name: "Vanguardia Estudiantil Dominicana",
  short: "VED4",
  campus: "Recinto UASD Santiago",
  founded: "16 de noviembre de 1985",
  founder: "Juan Bosch",
  semester: "2025-20",
  quote: "No basta tener ideas; hay que hacerlas realidad en lo grande y en lo minúsculo.",
  instagram: "https://www.instagram.com/ved4santiago",
  instagramHandle: "@ved4santiago",
  whatsapp: "https://chat.whatsapp.com/Iln1Lzi0MDFGVwtskLkYe0",
  whatsappGroup: "Nuevo Ingreso (VED4) 2026-20",
};

export const values = [
  { name: "Honestidad", text: "Decir la verdad y actuar con transparencia, también cuando cuesta." },
  { name: "Solidaridad", text: "Ningún estudiante avanza solo: se acompaña, se comparte, se cuida." },
  { name: "Responsabilidad", text: "Cumplir lo que se promete a la comunidad uasdiana." },
  { name: "Humildad", text: "Liderar escuchando, sin perder de vista de dónde venimos." },
  { name: "Empatía", text: "Entender la situación real de cada estudiante antes de opinar." },
  { name: "Respeto", text: "Convivir en la diferencia, dentro y fuera del recinto." },
];

export const purposes = [
  "Seguir siendo el grupo estudiantil con más líderes dentro de su directiva.",
  "Lograr la integración del estudiante a su universidad: cantos, poesía coreada, karate, taller literario Virgilio Díaz Grullón, softbol y básquet.",
  "Luchar por la equidad, el compromiso estudiantil y la igualdad de oportunidades dentro y fuera del recinto.",
  "Desarrollar el orgullo uasdiano y un pensamiento crítico para reflexionar sobre los problemas reales de la universidad.",
  "Formar líderes capaces de propalar las ideas del profesor Juan Bosch a las nuevas generaciones.",
  "Formar estudiantes ejemplares dentro y fuera del aula, fomentando la lectura crítica y comprensiva.",
  "Desarrollar una cultura del deporte y la integración del alumnado a las actividades lúdicas.",
];

/** Facultades del portal que aún no están sincronizadas en data/faculties.ts. */
export const pendingFaculties: Pick<Faculty, "id" | "name" | "monogram" | "color">[] = [
  { id: "ingenieria", name: "Facultad de Ingeniería y Arquitectura", monogram: "IA", color: "#475569" },
];
