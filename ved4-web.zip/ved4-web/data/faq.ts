export type FaqCategoryId = "admision" | "becas" | "tramites" | "grupos";

export interface FaqItem {
  q: string;
  a: string;
  link?: { label: string; href: string };
}

export interface FaqCategory {
  id: FaqCategoryId;
  label: string;
  items: FaqItem[];
}

export const faqCategories: FaqCategory[] = [
  {
    id: "admision",
    label: "Admisión y nuevo ingreso",
    items: [
      {
        q: "¿Cómo me ayuda la VED4 en mi inscripción?",
        a: "Cada período instalamos puntos de atención en el campus con computadoras e impresora para asistirte paso a paso: elegir la carrera, completar el proceso en línea y resolver dudas. Hemos acompañado a más de 500 estudiantes de nuevo ingreso en los últimos cuatrimestres.",
      },
      {
        q: "¿Qué documentos debo tener a mano?",
        a: "Por lo general se solicitan documentos de identidad, el récord o certificación de estudios de bachillerato y fotografías, además de completar la solicitud y los pasos de evaluación que indique la universidad. Los requisitos cambian por convocatoria, así que confírmalos con Admisiones o con nuestro equipo antes de ir.",
        link: { label: "Portal de la UASD", href: "https://uasd.edu.do" },
      },
      {
        q: "No conozco el campus. ¿Hay alguien que me oriente?",
        a: "Sí. Hacemos charlas y tours por el campus universitario y te ayudamos a ubicar edificios, escuelas y oficinas. Escríbenos por el grupo de WhatsApp de Nuevo Ingreso y coordinamos.",
      },
      {
        q: "¿Cómo sé cuál carrera me conviene?",
        a: "Revisa el pensum por facultad en esta misma página, compara las asignaturas de cada semestre y usa el simulador para ver cuánto tardarías. Si dudas entre dos opciones, pregunta en el grupo: estudiantes de cada escuela te cuentan cómo es el día a día.",
      },
    ],
  },
  {
    id: "becas",
    label: "Becas nacionales e internacionales",
    items: [
      {
        q: "¿Dónde encuentro becas nacionales para estudiar en la UASD?",
        a: "El Ministerio de Educación Superior, Ciencia y Tecnología (MESCYT) publica convocatorias de becas nacionales e internacionales para dominicanos. Revisa sus convocatorias abiertas, requisitos de índice académico y fechas de cierre directamente en su sitio.",
        link: { label: "MESCYT", href: "https://mescyt.gob.do" },
      },
      {
        q: "¿Y becas internacionales?",
        a: "Existen programas de gobiernos y organismos como Fulbright (Estados Unidos), Chevening (Reino Unido), DAAD (Alemania), Erasmus+ (Europa) y las becas del gobierno de Japón y de China. Muchas están dirigidas a posgrado y piden dominio de idioma, buen récord y cartas de recomendación; cada una tiene sus propias fechas y requisitos vigentes.",
      },
      {
        q: "¿Cómo me preparo para una beca?",
        a: "Cuida tu índice académico desde el primer semestre, trabaja el idioma (inglés técnico y certificaciones reconocidas), participa en actividades de liderazgo o voluntariado y guarda evidencias. Los documentos más pedidos son carta de motivación, récord de notas y recomendaciones.",
      },
      {
        q: "¿La universidad ofrece apoyo económico o ayudas internas?",
        a: "Consulta en la oficina de Bienestar Estudiantil y en la Vicerrectoría del recinto qué programas están activos. Si no sabes por dónde empezar, pregunta en el grupo de la VED4 y te indicamos a quién dirigirte.",
      },
    ],
  },
  {
    id: "tramites",
    label: "Guías de trámites",
    items: [
      {
        q: "¿Cómo hago la selección de asignaturas?",
        a: "Entra al portal de servicios estudiantiles con tu matrícula, revisa tu pensum, elige las asignaturas que cumplen prerrequisitos y verifica horarios y secciones disponibles. Hazlo dentro de las fechas del calendario académico, porque los cupos se agotan. Antes de confirmar, revisa que no choquen los horarios.",
      },
      {
        q: "¿Cómo pago los créditos?",
        a: "Al seleccionar tus asignaturas se genera la factura por los créditos inscritos. El pago se realiza por los canales habilitados por la universidad dentro del plazo establecido; conserva siempre el comprobante, porque lo pueden pedir si hay alguna diferencia.",
      },
      {
        q: "¿Cómo retiro una asignatura?",
        a: "El retiro se solicita dentro del período fijado en el calendario académico, normalmente en la escuela o por el canal que indique la universidad. Antes de retirar, revisa cómo afecta tus créditos, tus prerrequisitos y tu tiempo de graduación; puedes comprobarlo con el simulador.",
      },
      {
        q: "¿Dónde veo las fechas oficiales?",
        a: "Las fechas de inscripción, selección, pago y retiro las publica la UASD en su calendario académico. Si una fecha te genera duda, consúltala con tu escuela o escríbenos y te ayudamos a confirmarla.",
        link: { label: "Sitio de la UASD", href: "https://uasd.edu.do" },
      },
    ],
  },
  {
    id: "grupos",
    label: "Grupos de arte, deporte y literatura",
    items: [
      {
        q: "¿Qué grupos puedo integrar en la universidad?",
        a: "Grupos de cantos y de poesía coreada, el equipo de karate, el taller literario Virgilio Díaz Grullón y los equipos de softbol y básquet de la universidad, entre otros. Nuestro propósito es que vivas tu carrera con orgullo uasdiano, dentro y fuera del aula.",
      },
      {
        q: "¿Qué se necesita para integrarme?",
        a: "Ser estudiante activo y tener ganas de participar. Cada grupo define sus horarios, pruebas o requisitos, y te los confirma al contactarlo. Nosotros te conectamos con los responsables.",
      },
      {
        q: "¿Cómo me conecto con alguno?",
        a: "Escríbenos por Instagram (@ved4santiago) o por el grupo de WhatsApp de Nuevo Ingreso, cuéntanos qué te interesa y te decimos cuándo y dónde reunirte con ellos.",
      },
    ],
  },
];
