import type { GalleryCategory } from "./gallery";

export interface Achievement {
  title: string;
  detail: string;
  category: GalleryCategory;
  /** Archivo dentro de /public/gallery usado como imagen de la tarjeta. */
  image: string;
}

export const achievements: Achievement[] = [
  {
    title: "Más de 500 estudiantes de nuevo ingreso inscritos",
    detail: "Inscripción y asistencia guiada durante los últimos cuatrimestres.",
    category: "inscripcion",
    image: "/gallery/inscripcion-06.jpg",
  },
  {
    title: "Charlas, tours y acompañamiento integral",
    detail: "Recorridos por el campus y ayuda en todo el proceso de la carrera.",
    category: "acompanamiento",
    image: "/gallery/acompanamiento-05.jpg",
  },
  {
    title: "Donación de libros",
    detail: "Textos de la Fundación Juan Bosch y libros de diversas carreras universitarias.",
    category: "biblioteca",
    image: "/gallery/biblioteca-01.jpg",
  },
  {
    title: "Fiesta de Navidad estudiantil",
    detail: "Encuentro anual para compartir, hacer rifas, entregar helados y jugar.",
    category: "navidad",
    image: "/gallery/navidad-01.jpg",
  },
  {
    title: "Representación en la FED y el Consejo Directivo",
    detail: "Voz propia en la Federación de Estudiantes Dominicanos y en el Consejo Directivo de UASD Santiago.",
    category: "foros",
    image: "/gallery/foros-01.jpg",
  },
  {
    title: "Presencia constante en el recinto",
    detail: "Banderas, equipo y brigadas de orientación al inicio de cada período.",
    category: "movilizacion",
    image: "/gallery/movilizacion-01.jpg",
  },
];

export const milestones: string[] = [
  "Fumigación del recinto al inicio de cada año escolar.",
  "Rifas gratuitas de materiales y equipos para estudiantes de Medicina y Educación.",
  "Integración de profesores de Francés para Lenguas Modernas y Educación.",
  "Impermeabilización del techado del Recinto Ercilia Pepín (esquina San Luis).",
  "Compra de un maniquí avanzado de Cuidados Funcionales y de Traumas, con guantes e insumos médicos, para el edificio de Ciencias de la Salud.",
  "Refuerzo de la seguridad en la entrada de la universidad.",
];
