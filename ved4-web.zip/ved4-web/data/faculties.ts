import type { Faculty } from "@/lib/types";

/**
 * Fuente: https://app.uasd.edu.do/planesgrado/ (árbol de Planes de Grado).
 * Cada carrera enlaza a su pensum oficial. Para actualizar o completar este archivo ejecuta: npm run sync:planes
 */
export const faculties: Faculty[] = [
  {
    id: "artes",
    name: "Facultad de Artes",
    monogram: "AR",
    color: "#7C3AED",
    schools: [
      {
        name: "Escuela de Artes Plásticas",
        careers: [
          { name: "Licenciatura en Artes Plásticas", code: "30320", program: "P-APLA", plan: "200820" },
          { name: "Licenciatura en Artes Plásticas, mención Escultura", code: "30323", program: "P-ARPE", plan: "201010" },
          { name: "Licenciatura en Artes Plásticas, mención Pintura", code: "30322", program: "P-ARPP", plan: "201010" },
        ],
      },
      {
        name: "Escuela de Cine, TV y Fotografía",
        careers: [
          { name: "Licenciatura en Cinematografía y Audiovisuales, mención Cine", code: "30361", program: "P-CINC", plan: "201010" },
          { name: "Licenciatura en Cinematografía y Audiovisuales, mención Televisión", code: "30362", program: "P-CINT", plan: "201010" },
          { name: "Técnico en Fotografía y Medios Audiovisuales", code: "30363", program: "P-FOTA", plan: "201010" },
        ],
      },
      {
        name: "Escuela de Crítica e Historia del Arte",
        careers: [
          { name: "Licenciatura en Historia y Crítica del Arte", code: "30311", program: "P-HISA", plan: "201010" },
        ],
      },
      {
        name: "Escuela de Diseño Industrial y Modas",
        careers: [
          { name: "Licenciatura en Artes Industriales, mención Diseño Artesanal", code: "30372", program: "P-AIDA", plan: "201010" },
          { name: "Licenciatura en Artes Industriales, mención Diseño Industrial", code: "30373", program: "P-AIDI", plan: "201010" },
          { name: "Licenciatura en Artes Industriales, mención Diseño de Modas", code: "30371", program: "P-AIDM", plan: "201010" },
        ],
      },
      {
        name: "Escuela de Música",
        careers: [
          { name: "Licenciatura en Música", code: "30350", program: "P-MUS", plan: "200820" },
          { name: "Licenciatura en Música, mención Teoría y Educación Musical", code: "30355", program: "P-MUST", plan: "201010" },
        ],
      },
      {
        name: "Escuela de Publicidad",
        careers: [
          { name: "Licenciatura en Publicidad, mención Diseño", code: "30332", program: "P-ARPD", plan: "201010" },
          { name: "Licenciatura en Publicidad, mención Ilustración", code: "30331", program: "P-ARPI", plan: "201010" },
          { name: "Licenciatura en Publicidad, mención Creatividad y Gerencia", code: "30333", program: "P-PUBC", plan: "201010" },
        ],
      },
      {
        name: "Escuela de Teatro",
        careers: [
          { name: "Licenciatura en Teatro", code: "30340", program: "P-TEA", plan: "200820" },
          { name: "Licenciatura en Teatro, mención Actuación", code: "30341", program: "P-TEAA", plan: "201010" },
          { name: "Licenciatura en Teatro, mención Dirección", code: "30343", program: "P-TEAI", plan: "201010" },
          { name: "Licenciatura en Teatro, mención Dramaturgia", code: "30342", program: "P-TEDR", plan: "201010" },
        ],
      },
    ],
  },
  {
    id: "ciencias",
    name: "Facultad de Ciencias",
    monogram: "CI",
    color: "#0891B2",
    schools: [
      {
        name: "Escuela de Biología",
        careers: [
          { name: "Licenciatura en Biología", code: "40201", program: "P-BIOL", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Ciencias Geográficas",
        careers: [
          { name: "Licenciatura en Geografía, mención Recursos Naturales y Ecoturismo", code: "40303", program: "P-ECOT", plan: "000012" },
          { name: "Licenciatura en Geografía", code: "40302", program: "P-GEOG", plan: "000011" },
          { name: "Licenciatura en Geografía, mención Representación Espacial", code: "40304", program: "P-GEOR", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Física",
        careers: [
          { name: "Licenciatura en Física", code: "40401", program: "P-FISI", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Informática",
        careers: [
          { name: "Licenciatura en Informática", code: "40601", program: "P-INFO", plan: "200820" },
        ],
      },
      {
        name: "Escuela de Matemática",
        careers: [
          { name: "Licenciatura en Matemáticas", code: "40603", program: "P-MATE", plan: "201510" },
        ],
      },
      {
        name: "Escuela de Microbiología y Parasitología",
        careers: [
          { name: "Licenciatura en Microbiología", code: "40701", program: "P-MICR", plan: "201810" },
        ],
      },
      {
        name: "Escuela de Química",
        careers: [
          { name: "Licenciatura en Química", code: "40801", program: "P-QUIM", plan: "201110" },
          { name: "Tecnólogo Superior en Alimentos", code: "40803", program: "P-TSAL", plan: "201110" },
        ],
      },
    ],
  },
  {
    id: "economicas",
    name: "Facultad de Ciencias Económicas y Sociales",
    monogram: "EC",
    color: "#B45309",
    schools: [
      {
        name: "Escuela de Administración",
        careers: [
          { name: "Licenciatura en Administración de Empresas", code: "50201", program: "P-ADME", plan: "000013" },
          { name: "Licenciatura en Administración Pública", code: "50202", program: "P-ADMP", plan: "000013" },
        ],
      },
      {
        name: "Escuela de Contabilidad",
        careers: [
          { name: "Licenciatura en Contabilidad", code: "50301", program: "P-CONT", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Economía",
        careers: [
          { name: "Licenciatura en Aduana y Comercio Exterior", code: "50410", program: "P-ADCE", plan: "000014" },
          { name: "Licenciatura en Economía", code: "50401", program: "P-ECON", plan: "000013" },
        ],
      },
      {
        name: "Escuela de Estadística",
        careers: [
          { name: "Licenciatura en Estadística, mención Informática", code: "50504", program: "P-ESTI", plan: "000012" },
          { name: "Licenciatura en Estadística, mención Socioeconómica", code: "50503", program: "P-ESTS", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Mercadotecnia",
        careers: [
          { name: "Licenciatura en Mercadotecnia", code: "50203", program: "P-MERC", plan: "000013" },
        ],
      },
      {
        name: "Escuela de Sociología",
        careers: [
          { name: "Licenciatura en Sociología", code: "50601", program: "P-SOCI", plan: "000013" },
          { name: "Licenciatura en Trabajo Social", code: "50610", program: "P-TRAS", plan: "000014" },
        ],
      },
      {
        name: "Escuela de Turismo y Hotelería",
        careers: [
          { name: "Licenciatura en Turismo y Hotelería", code: "50801", program: "P-TURH", plan: "201810" },
        ],
      },
    ],
  },
  {
    id: "juridicas",
    name: "Facultad de Ciencias Jurídicas y Políticas",
    monogram: "JP",
    color: "#9F1239",
    schools: [
      {
        name: "Escuela de Ciencias Políticas",
        careers: [
          { name: "Licenciatura en Ciencias Políticas", code: "60301", program: "P-CSPO", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Derecho",
        careers: [
          { name: "Licenciatura en Derecho", code: "60202", program: "P-DERE", plan: "000012" },
        ],
      },
    ],
  },
  {
    id: "educacion",
    name: "Facultad de Ciencias de la Educación",
    monogram: "ED",
    color: "#1D4ED8",
    schools: [
      {
        name: "Escuela de Bibliotecología, Tecnología e Innovación",
        careers: [
          { name: "Licenciatura en Bibliotecología y Ciencias de la Información", code: "24701", program: "P-BCIN", plan: "201420" },
          { name: "Licenciatura en Educación, mención Bibliotecología", code: "30956", program: "P-EDBI", plan: "201120" },
          { name: "Licenciatura en Educación, mención Informática Educativa", code: "24702", program: "P-EMIE", plan: "201420" },
        ],
      },
      {
        name: "Escuela de Educación Física y Ciencias del Deporte",
        careers: [
          { name: "Licenciatura en Educación Física y Deporte", code: "24601", program: "P-EDFD", plan: "201420" },
          { name: "Licenciatura en Educación Física", code: "30957", program: "P-EDFI", plan: "201120" },
        ],
      },
      {
        name: "Escuela de Educación Infantil y Básica",
        careers: [
          { name: "Licenciatura en Educación Básica", code: "24355", program: "P-EDBA", plan: "201420" },
          { name: "Licenciatura en Educación Infantil", code: "24357", program: "P-EDIN", plan: "201420" },
          { name: "Licenciatura en Educación Básica (plan 2011)", code: "30955", program: "P-EDUB", plan: "201120" },
          { name: "Licenciatura en Educación Inicial", code: "30954", program: "P-EDUI", plan: "201120" },
          { name: "Licenciatura en Educación, mención Arte Escolar", code: "24356", program: "P-EMAE", plan: "201420" },
        ],
      },
      {
        name: "Escuela de Educación Media",
        careers: [
          { name: "Certificado ESE Ciencias Sociales", code: "30937", program: "P-CECS", plan: "000012" },
          { name: "Certificado ESE Francés", code: "30936", program: "P-CEFR", plan: "201120" },
          { name: "Certificado ESE Inglés", code: "30935", program: "P-CEIN", plan: "201120" },
          { name: "Licenciatura en Educación, mención Filosofía y Letras", code: "30903", program: "P-EDFF", plan: "201120" },
          { name: "Licenciatura en Educación Media, mención Biología y Química", code: "24404", program: "P-EMBQ", plan: "201420" },
          { name: "Licenciatura en Educación Media, mención Ciencias Sociales", code: "24405", program: "P-EMCS", plan: "201420" },
          { name: "Licenciatura en Educación Media, mención Física y Matemáticas", code: "24402", program: "P-EMFM", plan: "201420" },
          { name: "Licenciatura en Educación Media, mención Francés", code: "24407", program: "P-EMMF", plan: "201420" },
          { name: "Licenciatura en Educación Media, mención Inglés", code: "24408", program: "P-EMMI", plan: "201420" },
          { name: "Licenciatura en Educación Media, mención Letras", code: "24401", program: "P-EMML", plan: "201420" },
        ],
      },
      {
        name: "Escuela de Orientación Educativa y Psicopedagogía",
        careers: [
          { name: "Licenciatura en Educación Especial", code: "24502", program: "P-EDES", plan: "201420" },
          { name: "Licenciatura en Educación, mención Orientación Académica", code: "30951", program: "P-EDOA", plan: "201120" },
          { name: "Licenciatura en Educación, mención Orientación Socio-Comunitaria", code: "30952", program: "P-EDOC", plan: "201120" },
          { name: "Licenciatura en Educación, mención Orientación para el Desarrollo de Recursos Humanos", code: "30953", program: "P-EDOR", plan: "201120" },
          { name: "Licenciatura en Educación, mención Orientación Psicopedagógica", code: "24501", program: "P-EMOP", plan: "201420" },
        ],
      },
      {
        name: "Escuela de Teoría y Gestión Educativa",
        careers: [
          { name: "Licenciatura en Educación, mención Gestión Educativa", code: "24202", program: "P-EMGE", plan: "201420" },
          { name: "Licenciatura en Educación para Personas Jóvenes y Adultas", code: "24201", program: "P-EPJA", plan: "201420" },
        ],
      },
    ],
  },
  {
    id: "salud",
    name: "Facultad de Ciencias de la Salud",
    monogram: "SA",
    color: "#047857",
    schools: [
      {
        name: "Escuela de Bioanálisis",
        careers: [
          { name: "Licenciatura en Bioanálisis", code: "80902", program: "P-BIOA", plan: "000014" },
          { name: "Licenciatura en Imagenología", code: "80907", program: "P-IMAG", plan: "000014" },
          { name: "Técnico Radiólogo", code: "80906", program: "P-TRAD", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Enfermería",
        careers: [
          { name: "Licenciatura en Enfermería", code: "80601", program: "P-ENF1", plan: "000012" },
          { name: "Licenciatura en Enfermería (plan 000013)", code: "80603", program: "P-ENFE", plan: "000013" },
        ],
      },
      {
        name: "Escuela de Farmacia",
        careers: [
          { name: "Licenciatura en Farmacia", code: "80501", program: "P-FARM", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Medicina",
        careers: [
          { name: "Doctor en Medicina", code: "81001", program: "P-DMED", plan: "200920" },
          { name: "Pre-Médica / Medicina", code: "81002", program: "P-PMED", plan: "000014" },
        ],
      },
      {
        name: "Escuela de Odontología",
        careers: [
          { name: "Doctor en Odontología", code: "80801", program: "P-CODO", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Salud Pública",
        careers: [
          { name: "Técnico Superior en Atención Prehospitalaria", code: "80301", program: "P-TSAP", plan: "201820" },
        ],
      },
    ],
  },
  {
    id: "agronomicas",
    name: "Facultad de Ciencias Agronómicas y Veterinarias",
    monogram: "AG",
    color: "#4D7C0F",
    schools: [
      {
        name: "Escuela de Agronomía",
        careers: [
          { name: "Ingeniería Agronómica, mención Desarrollo Agrícola", code: "90210", program: "P-IADA", plan: "000012" },
          { name: "Ingeniería Agronómica, mención Producción de Cultivos", code: "90209", program: "P-IAPC", plan: "000012" },
          { name: "Ingeniería Agronómica, mención Suelo y Riego", code: "90208", program: "P-IASR", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Veterinaria",
        careers: [
          { name: "Licenciatura en Medicina Veterinaria", code: "90402", program: "P-MEDV", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Zootecnia",
        careers: [
          { name: "Ingeniería Lácteo Alimentaria", code: "90305", program: "P-ILAL", plan: "201810" },
          { name: "Ingeniería en Zootecnia", code: "90306", program: "P-IZOO", plan: "201810" },
          { name: "Tecnología en Procesos Lácteo Alimentarios", code: "90307", program: "P-TPLA", plan: "201810" },
        ],
      },
    ],
  },
  {
    id: "humanidades",
    name: "Facultad de Humanidades",
    monogram: "HU",
    color: "#0F766E",
    schools: [
      {
        name: "Escuela de Comunicación Social",
        careers: [
          { name: "Licenciatura en Comunicación Social, mención Comunicación Gráfica", code: "30405", program: "P-CSCG", plan: "000012" },
          { name: "Licenciatura en Comunicación Social, mención Periodismo", code: "30403", program: "P-CSPE", plan: "000012" },
          { name: "Licenciatura en Comunicación Social, mención Relaciones Públicas", code: "30404", program: "P-CSRP", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Filosofía",
        careers: [
          { name: "Licenciatura en Filosofía", code: "30501", program: "P-FILO", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Historia y Antropología",
        careers: [
          { name: "Licenciatura en Antropología", code: "30604", program: "P-ANTR", plan: "000012" },
          { name: "Licenciatura en Historia", code: "30601", program: "P-HIST", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Idiomas",
        careers: [
          { name: "Licenciatura en Lenguas Modernas, mención Francés", code: "30703", program: "P-LEMF", plan: "000012" },
          { name: "Licenciatura en Lenguas Modernas, mención Inglés", code: "30701", program: "P-LEMI", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Letras",
        careers: [
          { name: "Licenciatura en Letras", code: "30801", program: "P-LET", plan: "000012" },
        ],
      },
      {
        name: "Escuela de Psicología",
        careers: [
          { name: "Licenciatura en Psicología, mención Psicología del Desarrollo Humano", code: "31003", program: "P-HUMA", plan: "000012" },
        ],
      },
    ],
  },
];
