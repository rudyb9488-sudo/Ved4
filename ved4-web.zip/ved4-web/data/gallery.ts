export type GalleryCategory =
  | "equipo"
  | "inscripcion"
  | "acompanamiento"
  | "salud"
  | "biblioteca"
  | "foros"
  | "navidad"
  | "movilizacion";

export interface GalleryImage {
  src: string;
  alt: string;
  category: GalleryCategory;
  width: number;
  height: number;
}

export const galleryCategories: { id: GalleryCategory; label: string }[] = [
  { id: "equipo", label: "Equipo VED4" },
  { id: "inscripcion", label: "Nuevo ingreso" },
  { id: "acompanamiento", label: "Acompañamiento" },
  { id: "foros", label: "Charlas y foros" },
  { id: "salud", label: "Ciencias de la Salud" },
  { id: "biblioteca", label: "Libros y biblioteca" },
  { id: "navidad", label: "Navidad estudiantil" },
  { id: "movilizacion", label: "Movilización" },
];

export const galleryImages: GalleryImage[] = [
  { src: "/gallery/equipo-01.jpg", alt: "Integrantes de VED4 con banderas y camisetas de la agrupación", category: "equipo", width: 1280, height: 630 },
  { src: "/gallery/equipo-02.jpg", alt: "Integrantes de VED4 con banderas y camisetas de la agrupación", category: "equipo", width: 1280, height: 755 },
  { src: "/gallery/equipo-03.jpg", alt: "Integrantes de VED4 con banderas y camisetas de la agrupación", category: "equipo", width: 1126, height: 869 },
  { src: "/gallery/equipo-04.jpg", alt: "Integrantes de VED4 con banderas y camisetas de la agrupación", category: "equipo", width: 1280, height: 1010 },
  { src: "/gallery/equipo-05.jpg", alt: "Integrantes de VED4 con banderas y camisetas de la agrupación", category: "equipo", width: 1280, height: 671 },
  { src: "/gallery/equipo-06.jpg", alt: "Integrantes de VED4 con banderas y camisetas de la agrupación", category: "equipo", width: 1280, height: 960 },
  { src: "/gallery/equipo-07.jpg", alt: "Integrantes de VED4 con banderas y camisetas de la agrupación", category: "equipo", width: 960, height: 1280 },
  { src: "/gallery/equipo-08.jpg", alt: "Integrantes de VED4 con banderas y camisetas de la agrupación", category: "equipo", width: 1400, height: 933 },
  { src: "/gallery/equipo-09.jpg", alt: "Integrantes de VED4 con banderas y camisetas de la agrupación", category: "equipo", width: 1280, height: 960 },
  { src: "/gallery/inscripcion-01.jpg", alt: "Jornada de inscripción y atención a estudiantes de nuevo ingreso", category: "inscripcion", width: 1280, height: 949 },
  { src: "/gallery/inscripcion-02.jpg", alt: "Jornada de inscripción y atención a estudiantes de nuevo ingreso", category: "inscripcion", width: 1200, height: 900 },
  { src: "/gallery/inscripcion-03.jpg", alt: "Jornada de inscripción y atención a estudiantes de nuevo ingreso", category: "inscripcion", width: 1400, height: 1051 },
  { src: "/gallery/inscripcion-04.jpg", alt: "Jornada de inscripción y atención a estudiantes de nuevo ingreso", category: "inscripcion", width: 1280, height: 960 },
  { src: "/gallery/inscripcion-05.jpg", alt: "Jornada de inscripción y atención a estudiantes de nuevo ingreso", category: "inscripcion", width: 1205, height: 908 },
  { src: "/gallery/inscripcion-06.jpg", alt: "Jornada de inscripción y atención a estudiantes de nuevo ingreso", category: "inscripcion", width: 1280, height: 960 },
  { src: "/gallery/inscripcion-07.jpg", alt: "Jornada de inscripción y atención a estudiantes de nuevo ingreso", category: "inscripcion", width: 1280, height: 960 },
  { src: "/gallery/inscripcion-08.jpg", alt: "Jornada de inscripción y atención a estudiantes de nuevo ingreso", category: "inscripcion", width: 1280, height: 960 },
  { src: "/gallery/inscripcion-09.jpg", alt: "Jornada de inscripción y atención a estudiantes de nuevo ingreso", category: "inscripcion", width: 1280, height: 960 },
  { src: "/gallery/inscripcion-10.jpg", alt: "Jornada de inscripción y atención a estudiantes de nuevo ingreso", category: "inscripcion", width: 1280, height: 960 },
  { src: "/gallery/inscripcion-11.jpg", alt: "Jornada de inscripción y atención a estudiantes de nuevo ingreso", category: "inscripcion", width: 1280, height: 960 },
  { src: "/gallery/acompanamiento-01.jpg", alt: "Acompañamiento a estudiantes en el campus de la UASD Santiago", category: "acompanamiento", width: 1280, height: 960 },
  { src: "/gallery/acompanamiento-02.jpg", alt: "Acompañamiento a estudiantes en el campus de la UASD Santiago", category: "acompanamiento", width: 1280, height: 960 },
  { src: "/gallery/acompanamiento-03.jpg", alt: "Acompañamiento a estudiantes en el campus de la UASD Santiago", category: "acompanamiento", width: 1280, height: 960 },
  { src: "/gallery/acompanamiento-04.jpg", alt: "Acompañamiento a estudiantes en el campus de la UASD Santiago", category: "acompanamiento", width: 960, height: 1280 },
  { src: "/gallery/acompanamiento-05.jpg", alt: "Acompañamiento a estudiantes en el campus de la UASD Santiago", category: "acompanamiento", width: 1280, height: 960 },
  { src: "/gallery/acompanamiento-06.jpg", alt: "Acompañamiento a estudiantes en el campus de la UASD Santiago", category: "acompanamiento", width: 1280, height: 960 },
  { src: "/gallery/acompanamiento-07.jpg", alt: "Acompañamiento a estudiantes en el campus de la UASD Santiago", category: "acompanamiento", width: 1280, height: 960 },
  { src: "/gallery/acompanamiento-08.jpg", alt: "Acompañamiento a estudiantes en el campus de la UASD Santiago", category: "acompanamiento", width: 1280, height: 960 },
  { src: "/gallery/salud-01.jpg", alt: "Estudiantes de áreas de salud en práctica de laboratorio", category: "salud", width: 674, height: 354 },
  { src: "/gallery/salud-02.jpg", alt: "Estudiantes de áreas de salud en práctica de laboratorio", category: "salud", width: 1400, height: 737 },
  { src: "/gallery/salud-03.jpg", alt: "Estudiantes de áreas de salud en práctica de laboratorio", category: "salud", width: 1400, height: 737 },
  { src: "/gallery/salud-04.jpg", alt: "Estudiantes de áreas de salud en práctica de laboratorio", category: "salud", width: 586, height: 307 },
  { src: "/gallery/salud-05.jpg", alt: "Estudiantes de áreas de salud en práctica de laboratorio", category: "salud", width: 842, height: 443 },
  { src: "/gallery/biblioteca-01.jpg", alt: "Entrega de libros y visita a la Biblioteca Central de la UASD Santiago", category: "biblioteca", width: 1400, height: 933 },
  { src: "/gallery/biblioteca-02.jpg", alt: "Entrega de libros y visita a la Biblioteca Central de la UASD Santiago", category: "biblioteca", width: 1280, height: 1191 },
  { src: "/gallery/foros-01.jpg", alt: "Charla y encuentro estudiantil en el Recinto Santiago", category: "foros", width: 1280, height: 853 },
  { src: "/gallery/foros-02.jpg", alt: "Charla y encuentro estudiantil en el Recinto Santiago", category: "foros", width: 1280, height: 853 },
  { src: "/gallery/foros-03.jpg", alt: "Charla y encuentro estudiantil en el Recinto Santiago", category: "foros", width: 1280, height: 853 },
  { src: "/gallery/foros-04.jpg", alt: "Charla y encuentro estudiantil en el Recinto Santiago", category: "foros", width: 960, height: 960 },
  { src: "/gallery/foros-05.jpg", alt: "Charla y encuentro estudiantil en el Recinto Santiago", category: "foros", width: 960, height: 960 },
  { src: "/gallery/foros-06.jpg", alt: "Charla y encuentro estudiantil en el Recinto Santiago", category: "foros", width: 960, height: 960 },
  { src: "/gallery/foros-07.jpg", alt: "Charla y encuentro estudiantil en el Recinto Santiago", category: "foros", width: 960, height: 960 },
  { src: "/gallery/navidad-01.jpg", alt: "Encuentro navideño estudiantil en el campus", category: "navidad", width: 896, height: 652 },
  { src: "/gallery/navidad-02.jpg", alt: "Encuentro navideño estudiantil en el campus", category: "navidad", width: 1400, height: 1021 },
  { src: "/gallery/navidad-03.jpg", alt: "Encuentro navideño estudiantil en el campus", category: "navidad", width: 1400, height: 1021 },
  { src: "/gallery/navidad-04.jpg", alt: "Encuentro navideño estudiantil en el campus", category: "navidad", width: 1400, height: 1021 },
  { src: "/gallery/navidad-05.jpg", alt: "Encuentro navideño estudiantil en el campus", category: "navidad", width: 1400, height: 1021 },
  { src: "/gallery/navidad-06.jpg", alt: "Encuentro navideño estudiantil en el campus", category: "navidad", width: 1400, height: 1021 },
  { src: "/gallery/movilizacion-01.jpg", alt: "Estudiantes con banderas de VED4 frente a un edificio del campus", category: "movilizacion", width: 1271, height: 895 },
];
