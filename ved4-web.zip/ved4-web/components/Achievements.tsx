import Image from "next/image";
import Section from "./Section";
import { achievements, milestones } from "@/data/achievements";
import { galleryImages } from "@/data/gallery";

function dims(src: string) {
  const found = galleryImages.find((g) => g.src === src);
  return { width: found?.width ?? 1280, height: found?.height ?? 960, alt: found?.alt ?? "" };
}

export default function Achievements() {
  return (
    <Section
      id="logros"
      tone="paper"
      title="Lo que hemos logrado como Vanguardia Estudiantil"
      intro="Resultados concretos para la comunidad del Recinto Santiago, conseguidos con trabajo en el campus y desde el Consejo Directivo."
    >
      <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {achievements.map((a, i) => {
          const d = dims(a.image);
          return (
            <li
              key={a.title}
              className={`overflow-hidden rounded-2xl border border-line bg-white ${i === 0 ? "md:col-span-2 lg:col-span-2" : ""}`}
            >
              <Image
                src={a.image}
                alt={d.alt}
                width={d.width}
                height={d.height}
                sizes="(min-width: 1024px) 560px, (min-width: 768px) 50vw, 100vw"
                className={`w-full object-cover ${i === 0 ? "h-64 sm:h-72" : "h-52"}`}
              />
              <div className="p-5">
                <h3 className="text-lg font-semibold leading-snug">{a.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-navy-700">{a.detail}</p>
              </div>
            </li>
          );
        })}
      </ul>

      <div className="mt-12 rounded-2xl border border-line bg-white p-6 sm:p-8">
        <h3 className="text-xl font-semibold">Y también conseguimos</h3>
        <ul className="mt-5 grid gap-x-10 gap-y-3 text-sm leading-relaxed text-navy-800 md:grid-cols-2">
          {milestones.map((m) => (
            <li key={m} className="flex gap-3">
              <svg className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path d="M3 8.5l3 3 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span>{m}</span>
            </li>
          ))}
        </ul>
      </div>
    </Section>
  );
}
