"use client";

import Image from "next/image";
import { useEffect, useState } from "react";
import { site } from "@/data/site";

const links = [
  { href: "#identidad", label: "Quiénes somos" },
  { href: "#logros", label: "Logros" },
  { href: "#pensum", label: "Pensum" },
  { href: "#simulador", label: "Simulador" },
  { href: "#becas", label: "Becas y trámites" },
  { href: "#galeria", label: "Galería" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header className="sticky top-0 z-50 border-b border-line bg-white/90 backdrop-blur">
      <div className="container-page flex h-16 items-center justify-between gap-4">
        <a href="#" className="flex items-center gap-3" aria-label="VED4 Santiago, inicio">
          <Image src="/brand/ved4-logo.png" alt="" width={36} height={36} className="h-9 w-9 rounded-md object-cover" priority />
          <span className="font-display text-base font-semibold text-navy-900">
            VED4 <span className="font-normal text-navy-600">Santiago</span>
          </span>
        </a>

        <nav aria-label="Principal" className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="rounded-md px-3 py-2 text-sm font-medium text-navy-700 hover:bg-navy-50 hover:text-navy-900">
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a href={site.whatsapp} target="_blank" rel="noopener noreferrer" className="btn btn-primary hidden sm:inline-flex">
            Unirme al grupo
          </a>
          <button
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-line text-navy-800 lg:hidden"
            aria-expanded={open}
            aria-controls="menu-movil"
            aria-label={open ? "Cerrar menú" : "Abrir menú"}
            onClick={() => setOpen((v) => !v)}
          >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
              {open ? (
                <path d="M4 4l12 12M16 4L4 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              ) : (
                <path d="M3 6h14M3 10h14M3 14h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {open && (
        <nav id="menu-movil" aria-label="Menú móvil" className="border-t border-line bg-white lg:hidden">
          <ul className="container-page flex flex-col py-3">
            {links.map((l) => (
              <li key={l.href}>
                <a href={l.href} onClick={() => setOpen(false)} className="block rounded-md px-2 py-3 text-base font-medium text-navy-800 hover:bg-navy-50">
                  {l.label}
                </a>
              </li>
            ))}
            <li className="pt-2">
              <a href={site.whatsapp} target="_blank" rel="noopener noreferrer" className="btn btn-primary w-full">
                Unirme al grupo de Nuevo Ingreso
              </a>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
