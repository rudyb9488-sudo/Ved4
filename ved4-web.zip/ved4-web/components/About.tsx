import Image from "next/image";
import Section from "./Section";
import { purposes, site, values } from "@/data/site";

export default function About() {
  return (
    <Section
      id="identidad"
      title="Un movimiento estudiantil con más de cuarenta años de historia"
      intro="La VED4 Santiago lucha por la igualdad de género, la equidad y el bienestar estudiantil, siguiendo las consignas de Juan Bosch."
    >
      <div className="grid gap-12 lg:grid-cols-[1fr_1.05fr] lg:items-start">
        <div className="space-y-5 text-base leading-relaxed text-navy-800">
          <p>
            Fundada por el profesor {site.founder} el {site.founded}, la agrupación se ha ido intensificando con los años gracias a nuevas
            integraciones que se destacan por su liderazgo y su capacidad de fomentar una cultura crítica entre los uasdianos.
          </p>
          <p>
            Hoy cuenta con una sólida representación en la Federación de Estudiantes Dominicanos (FED) y en el Consejo Directivo del
            recinto UASD Santiago, fruto de un resultado contundente en las últimas elecciones estudiantiles: más de trescientos votos
            y un proyecto de política estudiantil construido en conjunto, con propuestas actuales.
          </p>
          <figure className="overflow-hidden rounded-2xl border border-line">
            <Image
              src="/gallery/equipo-03.jpg"
              alt="Integrantes de VED4 con camisetas verdes y la señal del número cuatro"
              width={1280}
              height={960}
              sizes="(min-width: 1024px) 480px, 100vw"
              className="h-72 w-full object-cover"
            />
          </figure>
        </div>

        <div className="space-y-10">
          <div>
            <h3 className="text-xl font-semibold">Los valores que nos guían</h3>
            <dl className="mt-5 grid gap-x-8 gap-y-5 sm:grid-cols-2">
              {values.map((v) => (
                <div key={v.name} className="border-l-2 border-emerald-500 pl-4">
                  <dt className="font-semibold text-navy-900">{v.name}</dt>
                  <dd className="mt-1 text-sm leading-relaxed text-navy-700">{v.text}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div>
            <h3 className="text-xl font-semibold">Nuestro propósito con los educandos</h3>
            <ul className="mt-5 space-y-3 text-sm leading-relaxed text-navy-800">
              {purposes.map((p) => (
                <li key={p} className="flex gap-3">
                  <span aria-hidden="true" className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-600" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </Section>
  );
}
