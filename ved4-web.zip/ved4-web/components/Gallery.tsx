"use client";

import Image from "next/image";
import { useCallback, useEffect, useRef, useState } from "react";
import Section from "./Section";
import { galleryCategories, galleryImages, type GalleryCategory } from "@/data/gallery";

type Filter = GalleryCategory | "todas";

export default function Gallery() {
  const [filter, setFilter] = useState<Filter>("todas");
  const [current, setCurrent] = useState<number | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const lastTrigger = useRef<HTMLElement | null>(null);

  const items = filter === "todas" ? galleryImages : galleryImages.filter((g) => g.category === filter);
  const label = (id: GalleryCategory) => galleryCategories.find((c) => c.id === id)?.label ?? "";

  const close = useCallback(() => {
    setCurrent(null);
    lastTrigger.current?.focus();
  }, []);
  const step = useCallback(
    (delta: number) => setCurrent((i) => (i === null ? i : (i + delta + items.length) % items.length)),
    [items.length],
  );

  useEffect(() => {
    if (current === null) return;
    closeRef.current?.focus();
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [current, close, step]);

  const selected = current === null ? null : items[current];

  return (
    <Section
      id="galeria"
      tone="paper"
      title="Galería de momentos"
      intro="La vida universitaria vista desde adentro: inscripciones, charlas, jornadas, libros y celebraciones con la comunidad del recinto."
    >
      <div role="group" aria-label="Filtrar fotos por categoría" className="flex flex-wrap gap-2">
        {([{ id: "todas", label: `Todas (${galleryImages.length})` }, ...galleryCategories] as { id: Filter; label: string }[]).map((c) => (
          <button
            key={c.id}
            type="button"
            aria-pressed={filter === c.id}
            onClick={() => setFilter(c.id)}
            className={`rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
              filter === c.id ? "border-navy-900 bg-navy-900 text-white" : "border-line bg-white text-navy-800 hover:bg-navy-50"
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      <ul className="mt-8 columns-1 gap-4 sm:columns-2 lg:columns-3">
        {items.map((img, i) => (
          <li key={img.src} className="mb-4 break-inside-avoid">
            <button
              type="button"
              className="group relative block w-full overflow-hidden rounded-xl border border-line bg-white"
              onClick={(e) => {
                lastTrigger.current = e.currentTarget;
                setCurrent(i);
              }}
              aria-label={`Ampliar foto: ${img.alt}`}
            >
              <Image
                src={img.src}
                alt={img.alt}
                width={img.width}
                height={img.height}
                sizes="(min-width: 1024px) 380px, (min-width: 640px) 50vw, 100vw"
                loading="lazy"
                className="h-auto w-full transition-transform duration-300 group-hover:scale-[1.03]"
              />
              <span className="absolute bottom-2 left-2 rounded-md bg-navy-950/75 px-2 py-1 text-xs font-medium text-white">
                {label(img.category)}
              </span>
            </button>
          </li>
        ))}
      </ul>

      {selected && (
        <div role="dialog" aria-modal="true" aria-label="Foto ampliada" className="fixed inset-0 z-[70] flex items-center justify-center bg-navy-950/95 p-4">
          <button ref={closeRef} type="button" onClick={close} className="absolute right-4 top-4 rounded-lg bg-white/10 px-4 py-2 text-sm font-semibold text-white hover:bg-white/20">
            Cerrar
          </button>
          <button type="button" onClick={() => step(-1)} aria-label="Foto anterior" className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white hover:bg-white/20">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M12.5 4l-6 6 6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </button>
          <figure className="max-h-full max-w-5xl">
            <Image
              src={selected.src}
              alt={selected.alt}
              width={selected.width}
              height={selected.height}
              sizes="100vw"
              className="max-h-[80vh] w-auto rounded-lg object-contain"
            />
            <figcaption className="mt-3 text-center text-sm text-navy-100">
              {selected.alt} ({(current ?? 0) + 1} de {items.length})
            </figcaption>
          </figure>
          <button type="button" onClick={() => step(1)} aria-label="Foto siguiente" className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white hover:bg-white/20">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M7.5 4l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </button>
        </div>
      )}
    </Section>
  );
}
