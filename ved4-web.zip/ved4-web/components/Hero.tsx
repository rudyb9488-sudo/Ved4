import Image from "next/image";
import { site } from "@/data/site";

export default function Hero() {
  return (
    <section aria-labelledby="hero-title" className="relative overflow-hidden bg-navy-950 text-white">
      <div className="absolute inset-0">
        <Image
          src="/gallery/movilizacion-01.jpg"
          alt="Estudiantes con banderas de VED4 frente a un edificio del campus de la UASD Santiago"
          fill
          priority
          sizes="100vw"
          className="object-cover opacity-45"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/85 to-navy-950/30" />
      </div>

      <div className="container-page relative grid min-h-[34rem] items-end gap-10 py-16 sm:py-24 lg:grid-cols-[1.25fr_1fr]">
        <div>
          <p className="text-sm font-medium text-emerald-100">
            Recinto UASD Santiago, fundada por Juan Bosch el {site.founded}
          </p>
          <h1 id="hero-title" className="mt-4 text-4xl font-semibold leading-[1.08] sm:text-5xl lg:text-6xl">
            Vanguardia Estudiantil Dominicana
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-navy-100">
            Te acompañamos desde tu inscripción hasta el último día de tu carrera: orientación, pensum claro, becas,
            trámites y una comunidad que lucha por la equidad y el bienestar estudiantil.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href={site.whatsapp} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
              Unirme al grupo de Nuevo Ingreso
            </a>
            <a href="#simulador" className="btn border border-white/30 bg-white/10 text-white hover:bg-white/20">
              Calcular cuándo termino mi carrera
            </a>
          </div>
        </div>

        <figure className="max-w-sm rounded-2xl border border-white/15 bg-navy-900/70 p-6 backdrop-blur lg:justify-self-end">
          <blockquote className="font-display text-xl leading-snug text-white">“{site.quote}”</blockquote>
          <figcaption className="mt-4 flex items-center gap-3 text-sm text-navy-200">
            <Image src="/brand/ved4-logo.png" alt="" width={40} height={40} className="h-10 w-10 rounded-md object-cover" />
            Bienvenidos al semestre {site.semester}
          </figcaption>
        </figure>
      </div>
    </section>
  );
}
