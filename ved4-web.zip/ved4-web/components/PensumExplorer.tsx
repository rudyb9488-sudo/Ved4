"use client";

import { useMemo, useState } from "react";
import Section from "./Section";
import { faculties } from "@/data/faculties";
import { pendingFaculties } from "@/data/site";
import type { Career, Faculty } from "@/lib/types";
import { PLANES_URL, careerLevel, normalize, pensumUrl } from "@/lib/utils";

export const CAREER_EVENT = "ved4:select-career";

function FacultyBadge({ faculty }: { faculty: Pick<Faculty, "monogram" | "color"> }) {
  return (
    <span
      aria-hidden="true"
      className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl font-display text-sm font-semibold text-white"
      style={{ backgroundColor: faculty.color }}
    >
      {faculty.monogram}
    </span>
  );
}

function CareerRow({ career }: { career: Career }) {
  const selectForSimulator = () => {
    window.dispatchEvent(new CustomEvent(CAREER_EVENT, { detail: { program: career.program } }));
    document.getElementById("simulador")?.scrollIntoView({ behavior: "smooth" });
  };
  return (
    <li className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="font-medium text-navy-900">{career.name}</p>
        <p className="mt-1 text-xs text-navy-600">
          {careerLevel(career.name)}. Código {career.code}, programa {career.program}, plan {career.plan}
        </p>
      </div>
      <div className="flex shrink-0 flex-wrap gap-2">
        <a
          href={pensumUrl(career)}
          target="_blank"
          rel="noopener noreferrer"
          className="btn btn-secondary px-3 py-2"
          aria-label={`Abrir el pensum oficial de ${career.name} en el portal de la UASD`}
        >
          Ver pensum oficial
        </a>
        <button type="button" onClick={selectForSimulator} className="btn btn-primary px-3 py-2" aria-label={`Usar ${career.name} en el simulador`}>
          Simular
        </button>
      </div>
    </li>
  );
}

export default function PensumExplorer() {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState<string | null>("ciencias");

  const q = normalize(query.trim());

  const filtered = useMemo(() => {
    return faculties
      .map((f) => ({
        ...f,
        schools: f.schools
          .map((s) => ({
            ...s,
            careers: q
              ? s.careers.filter((c) => normalize(`${c.name} ${c.code} ${c.program} ${s.name} ${f.name}`).includes(q))
              : s.careers,
          }))
          .filter((s) => s.careers.length > 0),
      }))
      .filter((f) => f.schools.length > 0);
  }, [q]);

  const totalCareers = filtered.reduce((n, f) => n + f.schools.reduce((m, s) => m + s.careers.length, 0), 0);

  return (
    <Section
      id="pensum"
      title="Pensum oficial por facultad"
      intro="Los planes de grado salen del portal oficial de la UASD y están agrupados por facultad y escuela. Abre cada carrera para ver sus asignaturas por semestre y descargar o imprimir el pensum desde el portal."
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="w-full sm:max-w-md">
          <label htmlFor="buscar-carrera" className="mb-1.5 block text-sm font-medium text-navy-800">
            Buscar carrera, escuela o código
          </label>
          <input
            id="buscar-carrera"
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ej.: Informática, Medicina, 40601"
            className="field"
            autoComplete="off"
          />
        </div>
        <p className="text-sm text-navy-600" aria-live="polite">
          {totalCareers} {totalCareers === 1 ? "carrera encontrada" : "carreras encontradas"}
        </p>
      </div>

      <div className="mt-6 divide-y divide-line overflow-hidden rounded-2xl border border-line">
        {filtered.length === 0 && (
          <p className="p-6 text-sm text-navy-700">
            No encontramos carreras con esa búsqueda. Prueba con otra palabra o revisa el listado completo en el{" "}
            <a className="font-medium text-emerald-700 underline" href={PLANES_URL} target="_blank" rel="noopener noreferrer">
              portal de planes de grado
            </a>
            .
          </p>
        )}

        {filtered.map((f) => {
          const expanded = q ? true : open === f.id;
          const count = f.schools.reduce((n, s) => n + s.careers.length, 0);
          return (
            <div key={f.id}>
              <h3>
                <button
                  type="button"
                  className="flex w-full items-center gap-4 px-5 py-4 text-left hover:bg-paper"
                  aria-expanded={expanded}
                  aria-controls={`panel-${f.id}`}
                  onClick={() => setOpen(expanded && !q ? null : f.id)}
                >
                  <FacultyBadge faculty={f} />
                  <span className="flex-1">
                    <span className="block text-base font-semibold text-navy-900">{f.name}</span>
                    <span className="block text-sm text-navy-600">
                      {f.schools.length} {f.schools.length === 1 ? "escuela" : "escuelas"} y {count} {count === 1 ? "carrera" : "carreras"}
                    </span>
                  </span>
                  <svg
                    className={`h-5 w-5 shrink-0 text-navy-600 transition-transform ${expanded ? "rotate-180" : ""}`}
                    viewBox="0 0 20 20"
                    fill="none"
                    aria-hidden="true"
                  >
                    <path d="M5 7.5l5 5 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              </h3>

              {expanded && (
                <div id={`panel-${f.id}`} className="border-t border-line bg-paper px-5 pb-4 pt-2">
                  {f.schools.map((s) => (
                    <div key={s.name} className="mt-4">
                      <h4 className="text-sm font-semibold text-navy-700">{s.name}</h4>
                      <ul className="mt-1 divide-y divide-line">
                        {s.careers.map((c) => (
                          <CareerRow key={c.program + c.plan} career={c} />
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}

        {!q &&
          pendingFaculties.map((f) => (
            <div key={f.id} className="flex items-center gap-4 px-5 py-4">
              <FacultyBadge faculty={f} />
              <div className="flex-1">
                <p className="text-base font-semibold text-navy-900">{f.name}</p>
                <p className="text-sm text-navy-600">Pendiente de sincronizar con el portal. Mientras tanto, consúltala directamente allí.</p>
              </div>
              <a href={PLANES_URL} target="_blank" rel="noopener noreferrer" className="btn btn-secondary px-3 py-2">
                Abrir portal
              </a>
            </div>
          ))}
      </div>

      <p className="mt-4 text-xs leading-relaxed text-navy-600">
        Fuente: {PLANES_URL}. El portal de la UASD es la referencia oficial; si un plan cambia, prevalece lo publicado allí.
      </p>
    </Section>
  );
}
