"use client";

import { useEffect, useMemo, useState } from "react";
import Section from "./Section";
import { CAREER_EVENT } from "./PensumExplorer";
import { faculties } from "@/data/faculties";
import { durationText, periodNoun, periodsPerYear, simulate } from "@/lib/simulator";
import type { PeriodType } from "@/lib/types";
import { pensumUrl } from "@/lib/utils";

const loadCopy = {
  ligera: { label: "Carga ligera", tone: "bg-navy-50 text-navy-800", hint: "Ritmo cómodo; ideal si trabajas o tienes otras responsabilidades." },
  moderada: { label: "Carga moderada", tone: "bg-emerald-50 text-emerald-700", hint: "Equilibrio entre avance y tiempo de estudio." },
  intensa: { label: "Carga intensa", tone: "bg-amber-100 text-amber-800", hint: "Exige mucho tiempo de estudio; revisa prerrequisitos y horarios antes de seleccionar." },
} as const;

const years = Array.from({ length: 6 }, (_, i) => 2026 + i);

function toInt(value: string): number {
  return value.trim() === "" ? NaN : Number(value);
}

export default function CurriculumSimulator() {
  const [facultyId, setFacultyId] = useState(faculties[0].id);
  const [program, setProgram] = useState(faculties[0].schools[0].careers[0].program);
  const [total, setTotal] = useState("40");
  const [approved, setApproved] = useState("0");
  const [perPeriod, setPerPeriod] = useState("5");
  const [periodType, setPeriodType] = useState<PeriodType>("semestre");
  const [startYear, setStartYear] = useState(2026);
  const [startPeriod, setStartPeriod] = useState(2);
  const [showTable, setShowTable] = useState(false);

  const faculty = faculties.find((f) => f.id === facultyId) ?? faculties[0];
  const career = faculty.schools.flatMap((s) => s.careers).find((c) => c.program === program) ?? faculty.schools[0].careers[0];

  useEffect(() => {
    const onSelect = (e: Event) => {
      const wanted = (e as CustomEvent<{ program: string }>).detail?.program;
      for (const f of faculties) {
        const hit = f.schools.flatMap((s) => s.careers).find((c) => c.program === wanted);
        if (hit) {
          setFacultyId(f.id);
          setProgram(hit.program);
          return;
        }
      }
    };
    window.addEventListener(CAREER_EVENT, onSelect);
    return () => window.removeEventListener(CAREER_EVENT, onSelect);
  }, []);

  const result = useMemo(
    () =>
      simulate({
        totalSubjects: toInt(total),
        approvedSubjects: toInt(approved),
        perPeriod: toInt(perPeriod),
        periodType,
        startYear,
        startPeriod,
      }),
    [total, approved, perPeriod, periodType, startYear, startPeriod],
  );

  const changeType = (t: PeriodType) => {
    setPeriodType(t);
    setStartPeriod((p) => Math.min(p, periodsPerYear[t]));
  };

  const error =
    result === null
      ? "Revisa los números: el total y las materias por período deben ser enteros mayores que cero, y las aprobadas no pueden superar el total."
      : null;

  return (
    <Section
      id="simulador"
      tone="paper"
      title="Simulador curricular"
      intro="Elige tu carrera, indica cuántas materias piensas cursar por período y calcula cuánto te falta para terminar, con el desglose de tu carga académica."
    >
      <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr]">
        <form className="space-y-5 rounded-2xl border border-line bg-white p-6" onSubmit={(e) => e.preventDefault()} aria-label="Datos del simulador">
          <div>
            <label htmlFor="sim-facultad" className="mb-1.5 block text-sm font-medium">Facultad</label>
            <select
              id="sim-facultad"
              className="field"
              value={facultyId}
              onChange={(e) => {
                const f = faculties.find((x) => x.id === e.target.value) ?? faculties[0];
                setFacultyId(f.id);
                setProgram(f.schools[0].careers[0].program);
              }}
            >
              {faculties.map((f) => (
                <option key={f.id} value={f.id}>{f.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="sim-carrera" className="mb-1.5 block text-sm font-medium">Carrera</label>
            <select id="sim-carrera" className="field" value={career.program} onChange={(e) => setProgram(e.target.value)}>
              {faculty.schools.map((s) => (
                <optgroup key={s.name} label={s.name}>
                  {s.careers.map((c) => (
                    <option key={c.program + c.plan} value={c.program}>{c.name}</option>
                  ))}
                </optgroup>
              ))}
            </select>
            <a href={pensumUrl(career)} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-sm font-medium text-emerald-700 underline">
              Abrir el pensum oficial de esta carrera para contar sus asignaturas
            </a>
          </div>

          <fieldset>
            <legend className="mb-1.5 text-sm font-medium">Tipo de período</legend>
            <div className="grid grid-cols-2 gap-3">
              {(["semestre", "cuatrimestre"] as PeriodType[]).map((t) => (
                <label
                  key={t}
                  className={`flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-2.5 text-sm ${periodType === t ? "border-emerald-600 bg-emerald-50" : "border-line"}`}
                >
                  <input type="radio" name="periodType" value={t} checked={periodType === t} onChange={() => changeType(t)} className="accent-emerald-600" />
                  <span className="capitalize">{t}</span>
                  <span className="text-xs text-navy-600">({periodsPerYear[t]} por año)</span>
                </label>
              ))}
            </div>
          </fieldset>

          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <label htmlFor="sim-total" className="mb-1.5 block text-sm font-medium">Materias del pensum</label>
              <input id="sim-total" inputMode="numeric" type="number" min={1} className="field" value={total} onChange={(e) => setTotal(e.target.value)} />
            </div>
            <div>
              <label htmlFor="sim-aprobadas" className="mb-1.5 block text-sm font-medium">Ya aprobadas</label>
              <input id="sim-aprobadas" inputMode="numeric" type="number" min={0} className="field" value={approved} onChange={(e) => setApproved(e.target.value)} />
            </div>
            <div>
              <label htmlFor="sim-carga" className="mb-1.5 block text-sm font-medium">Por {periodNoun[periodType]}</label>
              <input id="sim-carga" inputMode="numeric" type="number" min={1} max={20} className="field" value={perPeriod} onChange={(e) => setPerPeriod(e.target.value)} />
            </div>
          </div>
          <p className="-mt-2 text-xs leading-relaxed text-navy-600">
            El valor inicial de 40 materias es un ejemplo. Reemplázalo con el total del pensum oficial de tu carrera.
          </p>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="sim-anio" className="mb-1.5 block text-sm font-medium">Año de inicio</label>
              <select id="sim-anio" className="field" value={startYear} onChange={(e) => setStartYear(Number(e.target.value))}>
                {years.map((y) => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="sim-periodo" className="mb-1.5 block text-sm font-medium">Primer {periodNoun[periodType]} a cursar</label>
              <select id="sim-periodo" className="field" value={startPeriod} onChange={(e) => setStartPeriod(Number(e.target.value))}>
                {Array.from({ length: periodsPerYear[periodType] }, (_, i) => i + 1).map((p) => (
                  <option key={p} value={p}>{p}.º {periodNoun[periodType]}</option>
                ))}
              </select>
            </div>
          </div>
        </form>

        <div className="rounded-2xl border border-line bg-white p-6" aria-live="polite">
          {error && <p role="alert" className="rounded-lg bg-amber-100 p-4 text-sm text-amber-800">{error}</p>}

          {result && (
            <>
              <p className="text-sm text-navy-600">{career.name}</p>
              <p className="mt-2 font-display text-3xl font-semibold leading-tight sm:text-4xl">
                {result.periods === 0 ? "Carrera completada" : `Terminarías en ${result.endLabel}`}
              </p>
              <p className="mt-3 text-base text-navy-800">
                {result.periods === 0
                  ? "Ya aprobaste todas las materias del pensum."
                  : `Te faltan ${result.remaining} ${result.remaining === 1 ? "materia" : "materias"}: ${result.periods} ${result.periods === 1 ? periodNoun[periodType] : `${periodNoun[periodType]}s`} (${durationText(result, periodType)}).`}
              </p>

              <div className="mt-6">
                <div className="flex justify-between text-xs text-navy-600">
                  <span>Avance actual</span>
                  <span>{result.progressPercent}%</span>
                </div>
                <div
                  role="progressbar"
                  aria-label="Avance de la carrera"
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={result.progressPercent}
                  className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-navy-100"
                >
                  <div className="h-full rounded-full bg-emerald-600" style={{ width: `${result.progressPercent}%` }} />
                </div>
              </div>

              <div className={`mt-6 rounded-lg p-4 text-sm ${loadCopy[result.load].tone}`}>
                <p className="font-semibold">{loadCopy[result.load].label}: {perPeriod} por {periodNoun[periodType]}</p>
                <p className="mt-1">{loadCopy[result.load].hint}</p>
              </div>

              {result.rows.length > 0 && (
                <div className="mt-6">
                  <button type="button" className="btn btn-secondary px-3 py-2" aria-expanded={showTable} onClick={() => setShowTable((v) => !v)}>
                    {showTable ? "Ocultar desglose por período" : "Ver desglose por período"}
                  </button>
                  {showTable && (
                    <div className="mt-4 max-h-80 overflow-auto rounded-lg border border-line">
                      <table className="w-full text-left text-sm">
                        <caption className="sr-only">Desglose de materias por período</caption>
                        <thead className="sticky top-0 bg-paper text-navy-700">
                          <tr>
                            <th scope="col" className="px-3 py-2 font-medium">Período</th>
                            <th scope="col" className="px-3 py-2 font-medium">Materias</th>
                            <th scope="col" className="px-3 py-2 font-medium">Acumuladas</th>
                            <th scope="col" className="px-3 py-2 font-medium">Restantes</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-line">
                          {result.rows.map((r) => (
                            <tr key={r.index}>
                              <th scope="row" className="px-3 py-2 font-medium">{r.label}</th>
                              <td className="px-3 py-2">{r.subjects}</td>
                              <td className="px-3 py-2">{r.cumulative}</td>
                              <td className="px-3 py-2">{r.remaining}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              <p className="mt-6 text-xs leading-relaxed text-navy-600">
                Es una estimación lineal: no considera prerrequisitos, materias que se ofrecen solo en ciertos períodos ni el período de verano.
              </p>
            </>
          )}
        </div>
      </div>
    </Section>
  );
}
