"use client";

import { useMemo, useState } from "react";
import Section from "./Section";
import { faqCategories, type FaqCategoryId } from "@/data/faq";
import { normalize } from "@/lib/utils";

export default function ScholarshipCenter() {
  const [active, setActive] = useState<FaqCategoryId>("admision");
  const [query, setQuery] = useState("");
  const q = normalize(query.trim());

  const visible = useMemo(() => {
    if (q) {
      return faqCategories
        .map((c) => ({ ...c, items: c.items.filter((i) => normalize(`${i.q} ${i.a}`).includes(q)) }))
        .filter((c) => c.items.length > 0);
    }
    return faqCategories.filter((c) => c.id === active);
  }, [q, active]);

  const count = visible.reduce((n, c) => n + c.items.length, 0);

  return (
    <Section
      id="becas"
      title="Centro de becas y procesos universitarios"
      intro="Respuestas claras sobre admisión, becas, trámites y grupos estudiantiles. Es información orientativa: las fechas y requisitos vigentes los confirma siempre la UASD."
    >
      <div className="w-full sm:max-w-md">
        <label htmlFor="buscar-faq" className="mb-1.5 block text-sm font-medium text-navy-800">
          Buscar en todas las consultas
        </label>
        <input
          id="buscar-faq"
          type="search"
          className="field"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ej.: retiro, beca, softbol, documentos"
          autoComplete="off"
        />
      </div>

      {!q && (
        <div role="tablist" aria-label="Categorías de consulta" className="mt-6 flex flex-wrap gap-2">
          {faqCategories.map((c) => (
            <button
              key={c.id}
              id={`tab-${c.id}`}
              role="tab"
              type="button"
              aria-selected={active === c.id}
              aria-controls="faq-panel"
              onClick={() => setActive(c.id)}
              className={`rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
                active === c.id ? "border-navy-900 bg-navy-900 text-white" : "border-line bg-white text-navy-800 hover:bg-navy-50"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      )}

      <div id="faq-panel" role={q ? undefined : "tabpanel"} aria-labelledby={q ? undefined : `tab-${active}`} className="mt-6 space-y-8" aria-live="polite">
        {q && <p className="text-sm text-navy-600">{count} {count === 1 ? "resultado" : "resultados"}</p>}
        {visible.length === 0 && <p className="text-sm text-navy-700">No encontramos esa consulta. Escríbenos por el grupo de WhatsApp y te respondemos.</p>}

        {visible.map((c) => (
          <div key={c.id}>
            {q && <h3 className="mb-3 text-base font-semibold text-navy-700">{c.label}</h3>}
            <div className="divide-y divide-line overflow-hidden rounded-2xl border border-line">
              {c.items.map((item) => (
                <details key={item.q} className="group bg-white open:bg-paper">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 px-5 py-4 text-left font-medium text-navy-900 [&::-webkit-details-marker]:hidden">
                    <span>{item.q}</span>
                    <svg className="h-5 w-5 shrink-0 text-navy-600 transition-transform group-open:rotate-180" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                      <path d="M5 7.5l5 5 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </summary>
                  <div className="px-5 pb-5 text-sm leading-relaxed text-navy-800">
                    <p>{item.a}</p>
                    {item.link && (
                      <a href={item.link.href} target="_blank" rel="noopener noreferrer" className="mt-3 inline-block font-medium text-emerald-700 underline">
                        {item.link.label}
                      </a>
                    )}
                  </div>
                </details>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}
