import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface SectionProps {
  id: string;
  title: string;
  intro?: string;
  tone?: "white" | "paper" | "navy";
  children: ReactNode;
}

export default function Section({ id, title, intro, tone = "white", children }: SectionProps) {
  const dark = tone === "navy";
  return (
    <section
      id={id}
      aria-labelledby={`${id}-title`}
      className={cn(
        "py-16 sm:py-24",
        tone === "paper" && "bg-paper",
        dark && "bg-navy-900 text-white",
      )}
    >
      <div className="container-page">
        <div className="max-w-2xl">
          <h2 id={`${id}-title`} className="text-3xl font-semibold sm:text-4xl">
            {title}
          </h2>
          {intro && (
            <p className={cn("mt-4 text-base leading-relaxed sm:text-lg", dark ? "text-navy-200" : "text-navy-700")}>
              {intro}
            </p>
          )}
        </div>
        <div className="mt-10 sm:mt-12">{children}</div>
      </div>
    </section>
  );
}
