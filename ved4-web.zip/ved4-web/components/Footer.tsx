import Image from "next/image";
import { PLANES_URL } from "@/lib/utils";
import { site } from "@/data/site";

export default function Footer() {
  return (
    <footer className="bg-navy-950 text-navy-200">
      <div className="container-page grid gap-8 py-12 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-3">
            <Image src="/brand/ved4-logo.png" alt="" width={44} height={44} className="h-11 w-11 rounded-md object-cover" />
            <p className="font-display text-lg font-semibold text-white">{site.name}</p>
          </div>
          <p className="mt-4 max-w-sm text-sm leading-relaxed">
            {site.campus}. Fundada por {site.founder} el {site.founded}.
          </p>
        </div>

        <nav aria-label="Secciones" className="text-sm">
          <p className="font-semibold text-white">Explora</p>
          <ul className="mt-3 space-y-2">
            <li><a className="hover:text-white" href="#pensum">Pensum por facultad</a></li>
            <li><a className="hover:text-white" href="#simulador">Simulador curricular</a></li>
            <li><a className="hover:text-white" href="#becas">Becas y trámites</a></li>
            <li><a className="hover:text-white" href="#galeria">Galería</a></li>
          </ul>
        </nav>

        <div className="text-sm">
          <p className="font-semibold text-white">Comunidad</p>
          <ul className="mt-3 space-y-2">
            <li><a className="hover:text-white" href={site.whatsapp} target="_blank" rel="noopener noreferrer">WhatsApp Nuevo Ingreso</a></li>
            <li><a className="hover:text-white" href={site.instagram} target="_blank" rel="noopener noreferrer">Instagram {site.instagramHandle}</a></li>
            <li><a className="hover:text-white" href={PLANES_URL} target="_blank" rel="noopener noreferrer">Planes de grado UASD</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <p className="container-page py-5 text-xs leading-relaxed">
          Plataforma de la agrupación estudiantil VED4. Los planes de estudio provienen del portal oficial de la UASD, que es la referencia vigente.
        </p>
      </div>
    </footer>
  );
}
