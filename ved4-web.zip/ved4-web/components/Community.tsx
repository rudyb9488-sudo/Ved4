import Image from "next/image";
import Section from "./Section";
import { site } from "@/data/site";

export default function Community() {
  return (
    <Section
      id="comunidad"
      title="Súmate a la comunidad"
      intro="Los avisos de nuevo ingreso, las jornadas y las actividades se comparten primero en nuestros canales."
    >
      <div className="grid gap-6 md:grid-cols-2">
        <article className="flex flex-col justify-between rounded-2xl bg-emerald-600 p-7 text-white">
          <div>
            <h3 className="text-2xl font-semibold">Grupo de WhatsApp de Nuevo Ingreso</h3>
            <p className="mt-3 max-w-md text-emerald-50">
              {site.whatsappGroup}: resuelve dudas de inscripción, selección de materias y trámites con estudiantes que ya pasaron por eso.
            </p>
          </div>
          <a
            href={site.whatsapp}
            target="_blank"
            rel="noopener noreferrer"
            className="btn mt-8 w-fit bg-white text-emerald-700 hover:bg-emerald-50"
          >
            Entrar al grupo
          </a>
        </article>

        <article className="flex flex-col gap-6 rounded-2xl border border-line bg-white p-7 sm:flex-row sm:items-center">
          <Image
            src="/brand/qr-instagram.png"
            alt={`Código QR para abrir el Instagram ${site.instagramHandle}`}
            width={160}
            height={160}
            className="h-40 w-40 shrink-0 rounded-xl border border-line"
          />
          <div>
            <h3 className="text-2xl font-semibold">Síguenos en Instagram</h3>
            <p className="mt-3 text-navy-700">Fotos, convocatorias y avisos del recinto en {site.instagramHandle}.</p>
            <a href={site.instagram} target="_blank" rel="noopener noreferrer" className="btn btn-primary mt-5 w-fit">
              Abrir {site.instagramHandle}
            </a>
          </div>
        </article>
      </div>
    </Section>
  );
}
