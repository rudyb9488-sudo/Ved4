// Sincroniza data/faculties.ts con https://app.uasd.edu.do/planesgrado/
// Uso: npm run sync:planes   (requiere Node 18+ y acceso a internet)
// El portal entrega el árbol completo (Facultad > Escuela > Carrera) en el HTML.
import { writeFile } from "node:fs/promises";

const URL_PLANES = "https://app.uasd.edu.do/planesgrado/";
const COLORS = ["#7C3AED", "#0891B2", "#B45309", "#9F1239", "#1D4ED8", "#047857", "#4D7C0F", "#0F766E", "#475569", "#C2410C"];

const slug = (s) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
const decode = (s) => s.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
const monogram = (name) => {
  const words = name.replace(/^Facultad de /i, "").split(/\s+/).filter((w) => w.length > 2);
  return (words[0]?.[0] ?? "U").toUpperCase() + (words[1]?.[0] ?? words[0]?.[1] ?? "A").toUpperCase();
};

const res = await fetch(URL_PLANES);
if (!res.ok) throw new Error(`HTTP ${res.status} al leer ${URL_PLANES}`);
const html = await res.text();

// Recorremos el HTML en orden: nodos "Expand <nombre>" (facultad/escuela) y enlaces a PensumGrado (carreras).
const token = /title="Expand ([^"]+)"|<a[^>]*href="(https:\/\/app\.uasd\.edu\.do\/PensumGrado\/[^"]+)"[^>]*>([^<]+)<\/a>/g;

const faculties = [];
let faculty = null;
let school = null;
const seen = new Set();

for (const m of html.matchAll(token)) {
  if (m[1]) {
    const name = decode(m[1]).trim();
    if (/^Facultad/i.test(name)) {
      faculty = { id: slug(name.replace(/^Facultad de /i, "")), name, monogram: monogram(name), color: COLORS[faculties.length % COLORS.length], schools: [] };
      faculties.push(faculty);
      school = null;
    } else if (faculty) {
      school = { name, careers: [] };
      faculty.schools.push(school);
    }
  } else if (m[2] && school) {
    const href = decode(m[2]);
    const q = new URL(href).searchParams;
    const program = q.get("programa");
    const plan = q.get("plan");
    const label = decode(m[3]).trim();
    const code = label.match(/\(([^\s)-]+)\s*-/)?.[1] ?? "";
    const name = label.replace(/\s*-\s*\([^)]*\)\s*$/, "").trim();
    const key = `${program}|${plan}|${code}`;
    if (!program || !plan || !code || seen.has(key)) continue; // omite filas duplicadas o sin código
    seen.add(key);
    school.careers.push({ name, code, program, plan });
  }
}

const out = [
  'import type { Faculty } from "@/lib/types";',
  "",
  "/** Generado por scripts/sync-planes.mjs desde https://app.uasd.edu.do/planesgrado/ */",
  `export const faculties: Faculty[] = ${JSON.stringify(faculties, null, 2)};`,
  "",
].join("\n");

await writeFile(new URL("../data/faculties.ts", import.meta.url), out);
const careers = faculties.reduce((n, f) => n + f.schools.reduce((k, s) => k + s.careers.length, 0), 0);
console.log(`Listo: ${faculties.length} facultades y ${careers} carreras.`);
